const sentence = {
  
}

const classify = {
  
}

module.exports = {
  sentence,
  classify,
}
