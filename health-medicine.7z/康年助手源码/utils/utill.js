let _sentenceId;

const domain = 'https://www.cpcwe.com/wishes';
const storage = require('./wishes');

const _getRandom = (n) => {
  return Math.floor(Math.random() * parseInt(n))
}

const request = (opt,cb) => {
  wx.request({
    url:`${domain}/${opt.path}?app_name=wishes&relation_id=${opt.relation}&gender_id=${opt.sex}&wishes_id=${opt.id}`,
    type: opt.type || 'GET',
    success:(res) => {
      //实际上为请求失败，是对后端的容错处理
      if(typeof res.data.data === 'undefined'){
        console.log('remote-fail','res.data.data is undefined');
        if (opt.path === 'wishes'){
          cb(_changeOne(opt.relation,opt.sex,opt.id));
          //cb(this.getPublish());
          //this.setData({'sentence':});
        }
        if (opt.path === 'lists'){
          cb(_pushList(opt.relation,opt.sex,opt.id));
        }
        return;
      }

      console.log('remote-success',res.data.data)
      if (opt.path === 'wishes'){
        cb(res.data.data)
      }

      if (opt.path === 'lists'){
        cb(res.data.data)
      }
    },
   
  })
}

const formatNumber = (n) => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

const today = () =>{
  let year,month,day;
  let date = new Date();
  year = date.getFullYear();
  month = formatNumber(date.getMonth() + 1);
  day = formatNumber(date.getDate());
  return `${year}年${month}月${day}日`;
}

module.exports = {
  request,
  today
}
