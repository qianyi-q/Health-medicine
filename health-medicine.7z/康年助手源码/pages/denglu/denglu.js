Page({
  data:{
    zhanghao:'',
    mima:''
  },
  
  
    //获取输入的账号
    getzhanghao(event){
      // console.log('账号',event.detail.value)
      this.setData({
        zhanghao:event.detail.value
      })
    },
  
  //获取输入的密码
    getmima(event){
      // console.log('密码',event.detail.value)
      this.setData({
       mima:event.detail.value
      })
    },
  
  
  //点击登录
    login(){
      let zhanghao=this.data.zhanghao
      let mima=this.data.mima
      console.log('账号',zhanghao,'密码',mima)
     if(zhanghao.length!=11){
       wx.showToast({
         icon:'none',
         title:'账号应为11位',
       })
       return
     }
     if(mima.length<6){
      wx.showToast({
        icon:'none',
        title:'密码至少6位',
      })
      return
    }
  
    //登陆-请求对应数据
    wx.cloud.database().collection('YuanGong').where({
      zhanghao:zhanghao
    }).get({
      success(res){
        console.log('获取数据成功',res)
        let YuanGong=res.data[0]
        console.log("YuanGong",YuanGong)
        if(mima==YuanGong.mima){
          console.log('登陆成功')
          wx.showToast({
            title:'登陆成功',
          })
          //页面的跳转
          wx.switchTab({
            url: '../index/index'
          })
          //保存用户登录状态
          wx.setStorageSync('YuanGong', YuanGong)
  
        }else{
          console.log('登陆失败')
          wx.showToast({
            icon:'none',
            title: '账号或密码不符',
          })
        }
  
      },
      fail(res){
        console.log('获取数据失败',res)
      }
    })
    }
  })
  