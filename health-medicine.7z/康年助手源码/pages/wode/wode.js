var app = getApp()
Page({
  data: {
    avatarUrl: "",
    nickName: "",
    winWidth: ""
  },
  onShow: function () {
    var that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth
        });
      }
    });
    that.setData({
      avatarUrl: app.globalData.userInfo.avatarUrl,
      nickName: app.globalData.userInfo.nickName
    })
  },
  sysConf: function () {
    wx.navigateTo({
      url: '../bangding/bangding'
    })
  },
  feedback: function () {
    wx.navigateTo({
      url: '../toutiao/toutiao'
    })
  },
  geren: function () {
    wx.navigateTo({
      url: '../geren/geren'
    })
  }
}) 