const db = wx.cloud.database()
var filePath = [];

Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataObj: "",
    url:[]
  },

  getData() {
    db.collection("demolist").get({
      success: res => {
        console.long(res)
        this.setData({
          dataObj: res.data
        })
      }
    })
  },

  btnSub(e) {
    console.log('btnsub',e)
    var title = e.detail.value.author
    var image = this.data.url
    
    db.collection("demolist").add({
      data: {
        title: title,
        image:image
      }
    }).then(res=>{
      wx.showToast({
        title: '保存成功',
        icon:'none'
      })
    })
  },

  clickBtn() {
    wx.chooseImage({
      success: res => {
        console.log('res:', res)
        filePath = res.tempFilePaths

        filePath.forEach((item, idx) => {
          var filiname = Date.now() + "_" + idx;
          this.cloudFile(filiname, item)
        })
      }
    })
  },


  cloudFile(filiname, path) {
    let that = this
    wx.showLoading({
      title: '上传中...',
    })
    wx.cloud.uploadFile({
      cloudPath: filiname + ".jpg",
      filePath: path,
      success: res => {
        // 返回文件 ID
        console.log('uoload:', res)
        let url = that.data.url
        url.push(res.fileID)
        that.setData({url})
        wx.hideLoading()
      },
      fail: err => {
        wx.hideLoading()
      }
    })

  }


})