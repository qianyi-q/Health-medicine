//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000 ,
    text1:'这是一个段落 看我空格',
    cardTeams: [{
      "viewid": "1",
      "imgsrc": "https://pic.liesio.com/2020/05/20/5cf6d2108f3dc.jpg",
      "price": "¥1245",
      "count": "百姓康年养老公寓为松北区点赞",
      "name": "尽忠职守解忧患 防控为民见真情",

    }, {
      "viewid": "2",
      "imgsrc": "https://pic.liesio.com/2020/05/20/77e98bcb3e585.jpg",
      "price": "¥2345",
      "count": "团结奋战、抗击疫情、护你平安",
      "name": "致敬我眼中的英雄",

    }, {
      "viewid": "3",
      "imgsrc": "https://pic.liesio.com/2020/05/20/b4c22f7ed191a.jpg",
      "price": "¥2345",

      "count": "疫情无情人有情",
      "name": "百姓康年坚守疫情",

    }, {
      "viewid": "4",
      "imgsrc": "https://pic.liesio.com/2020/05/20/c18b11330a202.jpg",
      "price": "¥2345",
      "count": "百姓康年全体员工住大家新年快乐！",
      "name": "最香的年夜饭",

    },
    {
      "viewid": "5",
      "imgsrc": "https://pic.liesio.com/2020/05/20/09a86dcfc83bf.jpg",
      "price": "¥2345",
      "count": "百姓康年联欢会",
      "name": "欢欢喜喜过大年",

    }]
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../weixinlink/weixinlink'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
